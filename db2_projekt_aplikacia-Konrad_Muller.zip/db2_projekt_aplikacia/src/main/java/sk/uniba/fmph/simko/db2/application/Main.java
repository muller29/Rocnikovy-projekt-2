package sk.uniba.fmph.simko.db2.application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import org.postgresql.ds.PGSimpleDataSource;
import sk.uniba.fmph.simko.db2.application.ui.MainMenu;


/**
 *
 * @author Alexander Šimko
 * @author Konád Müller
 */


public class Main {

    public static void main(String[] args) throws SQLException, IOException {

        PGSimpleDataSource dataSource = new PGSimpleDataSource();

        dataSource.setServerName("db.dai.fmph.uniba.sk");
        dataSource.setPortNumber(5432);
        dataSource.setDatabaseName("playground");
        dataSource.setUser("muller29@uniba.sk");
        dataSource.setPassword("asd123");

        try (Connection connection = dataSource.getConnection()) {
            DbContext.setConnection(connection);

            MainMenu mainMenu = new MainMenu();
            mainMenu.run();

        } finally {
            DbContext.clear();
        }
    }
}
