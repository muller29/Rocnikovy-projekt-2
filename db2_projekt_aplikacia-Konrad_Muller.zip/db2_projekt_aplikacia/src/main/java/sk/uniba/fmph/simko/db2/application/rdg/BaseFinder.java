package sk.uniba.fmph.simko.db2.application.rdg;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import sk.uniba.fmph.simko.db2.application.DbContext;

/**
 *
 * @author Alexander Šimko
 * @author Konád Müller
 *
 * casti kodu, ktorych autorom je Alexander Šimko su oynacene
 */


// autor - Alexander Šimko - zac
public abstract class BaseFinder<T> {

    protected List<T> findAll(String query) throws SQLException {
        if (query == null) {
            throw new NullPointerException("query cannot be null");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement(query)) {
            try (ResultSet r = s.executeQuery()) {

                List<T> elements = new ArrayList<>();

                while (r.next()) {
                    elements.add(load(r));
                }

                return elements;
            }
        }
    }

    protected T findByInt(String query, int value) throws SQLException {
        if (query == null) {
            throw new NullPointerException("query cannot be null");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement(query)) {
            s.setInt(1, value);

            try (ResultSet r = s.executeQuery()) {
                if (r.next()) {
                    T c = load(r);

                    if (r.next()) {
                        throw new RuntimeException("More than one row was returned");
                    }

                    return c;
                } else {
                    return null;
                }

            }
        }
    }


    protected abstract T load(ResultSet r) throws SQLException;

    // autor - Alexander Šimko - kon

    // autor - Konrad Müller

    protected T findByTwoInts(String query, int value1, int value2) throws SQLException{
        if(query == null){
            throw new NullPointerException("query cannot be null");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement(query)) {
            s.setInt(1, value1);
            s.setInt(2, value2);

            try (ResultSet r = s.executeQuery()) {
                if (r.next()) {
                    T c = load(r);

                    if (r.next()) {
                        throw new RuntimeException("More than one row was returned");
                    }

                    return c;
                } else {
                    return null;
                }

            }
        }
    }

    protected T findByLong(String query, Long value) throws SQLException {
        if (query == null) {
            throw new NullPointerException("query cannot be null");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement(query)) {
            s.setLong(1, value);

            try (ResultSet r = s.executeQuery()) {
                if (r.next()) {
                    T c = load(r);

                    if (r.next()) {
                        throw new RuntimeException("More than one row was returned");
                    }

                    return c;
                } else {
                    return null;
                }

            }
        }
    }

    protected List<T> findAllByInt(String query, Integer value) throws SQLException {
        if (query == null) {
            throw new NullPointerException("query cannot be null");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement(query)) {
            s.setInt(1, value);
            try (ResultSet r = s.executeQuery()) {

                List<T> elements = new ArrayList<>();

                while (r.next()) {
                    elements.add(load(r));
                }

                return elements;
            }
        }
    }

    protected List<T> findAllByIntAndString(String query, Integer value, String value2) throws SQLException {
        if (query == null) {
            throw new NullPointerException("query cannot be null");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement(query)) {
            s.setInt(1, value);
            s.setString(2, value2);
            try (ResultSet r = s.executeQuery()) {

                List<T> elements = new ArrayList<>();

                while (r.next()) {
                    elements.add(load(r));
                }

                return elements;
            }
        }
    }

}
