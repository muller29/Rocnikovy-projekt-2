package sk.uniba.fmph.simko.db2.application.rdg;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author Konád Müller
 */

public class Kurz extends BaseGateway{

    private Integer id;
    private BigDecimal kurz;
    private Integer zMeny;
    private Integer naMenu;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public BigDecimal getKurz() {
        return kurz;
    }

    public void setKurz(BigDecimal kurz) {
        this.kurz = kurz;
    }

    public Integer getzMeny() {
        return zMeny;
    }

    public void setzMeny(Integer zMeny) {
        this.zMeny = zMeny;
    }

    public Integer getNaMenu() {
        return naMenu;
    }

    public void setNaMenu(Integer naMenu) {
        this.naMenu = naMenu;
    }

    @Override
    protected void insertFill(PreparedStatement s) throws SQLException {
        s.setBigDecimal(1, kurz);
        s.setInt(2, zMeny);
        s.setInt(3, naMenu);
    }

    public void insert() throws SQLException{
        insert("INSERT INTO kurzy (kurz, zMeny, naMenu) " +
                "VALUES (?, ?, ?)");
    }

    @Override
    protected void insertUpdateKeys(ResultSet r) throws SQLException {

    }

    @Override
    protected void updateFill(PreparedStatement s) throws SQLException {
        s.setBigDecimal(1, kurz);
        s.setInt(2, id);
    }

    public void update() throws SQLException{
        update("UPDATE kurzy SET kurz = ? WHERE id = ?");
    }

    @Override
    protected void deleteFill(PreparedStatement s) throws SQLException {
        s.setInt(1, id);
    }

    public void delete() throws SQLException{
        delete("DELETE FROM kurzy WHERE id = ?");
    }
}
