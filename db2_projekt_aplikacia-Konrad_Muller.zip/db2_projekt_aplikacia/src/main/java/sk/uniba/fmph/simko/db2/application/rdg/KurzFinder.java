package sk.uniba.fmph.simko.db2.application.rdg;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;


/**
 *
 * @author Konád Müller
 */


public class KurzFinder extends BaseFinder {

    private static final KurzFinder INSTANCE = new KurzFinder();

    public static KurzFinder getInstance() {
        return INSTANCE;
    }

    private KurzFinder() {
    }

    public Kurz findById(Integer id) throws SQLException{
        return (Kurz) findByInt("SELECT * FROM kurzy WHERE id = ?", id);
    }

    public List<Kurz> findAll() throws SQLException{
        return findAll("SELECT * FROM kurzy");
    }

    public Kurz findByTwoInts(int zMeny, int naMenu) throws SQLException {
        return (Kurz) findByTwoInts("SELECT * FROM kurzy WHERE zMeny = ? AND naMenu = ?", zMeny, naMenu);
    }

    @Override
    protected Object load(ResultSet r) throws SQLException {
        Kurz k = new Kurz();

        k.setId(r.getInt("id"));
        k.setKurz(r.getBigDecimal("kurz"));
        k.setzMeny(r.getInt("zMeny"));
        k.setNaMenu(r.getInt("naMenu"));

        return k;
    }


}
