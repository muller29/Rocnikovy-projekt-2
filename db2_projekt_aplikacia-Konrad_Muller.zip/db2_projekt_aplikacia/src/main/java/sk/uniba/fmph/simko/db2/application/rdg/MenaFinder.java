package sk.uniba.fmph.simko.db2.application.rdg;

import java.sql.ResultSet;
import java.sql.SQLException;


/**
 *
 * @author Konád Müller
 */


public class MenaFinder extends BaseFinder{
    private static final MenaFinder INSTANCE = new MenaFinder();

    public static MenaFinder getInstance() {
        return INSTANCE;
    }

    private MenaFinder() {
    }

    @Override
    protected Object load(ResultSet r) throws SQLException {
        Mena m = new Mena();

        m.setId(r.getInt("id"));
        m.setNazov(r.getString("nazov"));

        return m;
    }

    public Mena findById(Integer id) throws SQLException {
        return (Mena) findByInt("SELECT * FROM meny WHERE id = ?", id);
    }

}
