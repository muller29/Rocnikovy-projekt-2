package sk.uniba.fmph.simko.db2.application.rdg;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 *
 * @author Konád Müller
 */


public class PlatobnaKarta extends BaseGateway{

    private Integer id;
    private Integer kod;
    private Integer ucetId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getKod() {
        return kod;
    }

    public void setKod(Integer kod) {
        this.kod = kod;
    }

    public Integer getUcetId() {
        return ucetId;
    }

    public void setUcetId(Integer ucetId) {
        this.ucetId = ucetId;
    }

    @Override
    protected void insertFill(PreparedStatement s) throws SQLException {

    }

    @Override
    protected void insertUpdateKeys(ResultSet r) throws SQLException {

    }

    @Override
    protected void updateFill(PreparedStatement s) throws SQLException {

    }

    @Override
    protected void deleteFill(PreparedStatement s) throws SQLException {

    }
}
