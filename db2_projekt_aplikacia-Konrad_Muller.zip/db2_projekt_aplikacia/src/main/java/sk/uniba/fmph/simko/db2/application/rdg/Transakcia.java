package sk.uniba.fmph.simko.db2.application.rdg;



import java.math.BigDecimal;
import java.sql.*;


/**
 *
 * @author Konád Müller
 */


public class Transakcia extends BaseGateway{

    private Integer id;
    private Integer ucetId;
    private Integer kartaId;
    private BigDecimal suma;
    private Date datum;
    private String typ;
    private Integer cisloProtiuctu;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUcetId() {
        return ucetId;
    }

    public void setUcetId(Integer ucetId) {
        this.ucetId = ucetId;
    }

    public Integer getKartaId() {
        return kartaId;
    }

    public void setKartaId(Integer kartaId) {
        this.kartaId = kartaId;
    }

    public BigDecimal getSuma() {
        return suma;
    }

    public void setSuma(BigDecimal suma) {
        this.suma = suma;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public String getTyp() {
        return typ;
    }

    public void setTyp(String typ) {
        this.typ = typ;
    }

    public Integer getCisloProtiuctu() {
        return cisloProtiuctu;
    }

    public void setCisloProtiuctu(Integer cisloProtiuctu) {
        this.cisloProtiuctu = cisloProtiuctu;
    }

    @Override
    protected void insertFill(PreparedStatement s) throws SQLException {
        s.setInt(1, ucetId);
        if (kartaId == null){
            s.setNull(2, Types.INTEGER);
        }
        else {
            s.setInt(2, kartaId);
        }
        s.setBigDecimal(3, suma);
        s.setDate(4, datum);
        s.setString(5, typ);
        if (cisloProtiuctu == null){
            s.setNull(6, Types.INTEGER);
        }
        else{
            s.setInt(6, cisloProtiuctu);
        }
    }

    public void insert()throws SQLException{
        insert("INSERT INTO transakcie (ucetId, kartaId, suma, datum, " +
                "typ, cisloProtiuctu) " +
                "VALUES (?, ?, ?, ?, ?, ?)");
    }

    @Override
    protected void insertUpdateKeys(ResultSet r) throws SQLException {

    }

    @Override
    protected void updateFill(PreparedStatement s) throws SQLException {

    }

    @Override
    protected void deleteFill(PreparedStatement s) throws SQLException {

    }
}
