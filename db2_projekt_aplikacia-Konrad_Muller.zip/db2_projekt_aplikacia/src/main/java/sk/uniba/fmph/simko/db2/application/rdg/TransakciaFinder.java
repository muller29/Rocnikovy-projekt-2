package sk.uniba.fmph.simko.db2.application.rdg;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;


/**
 *
 * @author Konád Müller
 */


public class TransakciaFinder extends BaseFinder {

    private static final TransakciaFinder INSTANCE = new TransakciaFinder();

    public static TransakciaFinder getInstance() {
        return INSTANCE;
    }

    private TransakciaFinder() {
    }

    public List<Transakcia> findAllByAccountId(Integer id) throws SQLException {
        return findAllByInt("SELECT * FROM transakcie WHERE ucetId = ?", id);
    }

    public List<Transakcia> findAllTaxTransByAccountId(Integer id) throws SQLException {
        return findAllByInt("SELECT * FROM transakcie WHERE ucetId = ?" +
                "AND EXTRACT(MONTH FROM datum) = EXTRACT(MONTH FROM current_date) " +
                "AND EXTRACT(YEAR FROM datum) = EXTRACT(YEAR FROM current_date) " +
                "AND typ IN ('vklad-hotovost', 'vyber-hotovost', 'vyber-kartou')", id);
    }

    public List<Transakcia> findAllTransInCurrMonthByAcc(Integer id) throws SQLException {
        return findAllByInt("SELECT * FROM transakcie t WHERE t.ucetId = ? AND " +
                "EXTRACT(MONTH FROM t.datum) = EXTRACT(MONTH FROM current_date) AND " +
                "EXTRACT(YEAR FROM datum) = EXTRACT(YEAR FROM current_date) AND " +
                "typ = 'prevod-sporiaci'", id);
    }

    @Override
    protected Object load(ResultSet r) throws SQLException {
        Transakcia t = new Transakcia();

        t.setId(r.getInt("id"));
        t.setUcetId(r.getInt("ucetId"));
        t.setKartaId(r.getInt("kartaId"));
        t.setSuma(r.getBigDecimal("suma"));
        t.setDatum(r.getDate("datum"));
        t.setTyp(r.getString("typ"));
        t.setCisloProtiuctu(r.getInt("cisloProtiuctu"));

        return t;
    }
}
