package sk.uniba.fmph.simko.db2.application.rdg;

import java.math.BigDecimal;
import java.sql.*;

import sk.uniba.fmph.simko.db2.application.DbContext;


/**
 *
 * @author Konrád Müller
 */


public class Ucet extends BaseGateway{

    private Integer id;
    private BigDecimal suma;
    private BigDecimal sumaTrans;
    private Boolean aktivny;
    private Date datumVytvorenia;
    private Integer zakaznikId;
    private Integer menaId;
    private String typ;
    private BigDecimal urok;
    private Date dobaViazanosti;
    private Integer prepojenie;

    public Integer getId() {
        return id;
    }

    public BigDecimal getSuma() {
        return suma;
    }

    public BigDecimal getSumaTrans() {
        return sumaTrans;
    }

    public Boolean getAktivny() {
        return aktivny;
    }

    public Date getDatumVytvorenia() {
        return datumVytvorenia;
    }

    public Integer getZakaznikId() {
        return zakaznikId;
    }

    public Integer getMenaId() {
        return menaId;
    }

    public String getTyp() {
        return typ;
    }

    public BigDecimal getUrok() {
        return urok;
    }

    public Date getDobaViazanosti() {
        return dobaViazanosti;
    }

    public Integer getPrepojenie() {
        return prepojenie;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setSuma(BigDecimal suma) {
        this.suma = suma;
    }

    public void setSumaTrans(BigDecimal sumaTrans) {
        this.sumaTrans = sumaTrans;
    }

    public void setAktivny(Boolean aktivny) {
        this.aktivny = aktivny;
    }

    public void setDatumVytvorenia(Date datumVytvorenia) {
        this.datumVytvorenia = datumVytvorenia;
    }

    public void setZakaznikId(Integer zakaznikId) {
        this.zakaznikId = zakaznikId;
    }

    public void setMenaId(Integer menaId) {
        this.menaId = menaId;
    }

    public void setTyp(String typ) {
        this.typ = typ;
    }

    public void setUrok(BigDecimal urok) {
        this.urok = urok;
    }

    public void setDobaViazanosti(Date dobaViazanosti) {
        this.dobaViazanosti = dobaViazanosti;
    }

    public void setPrepojenie(Integer prepojenie) {
        this.prepojenie = prepojenie;
    }


    @Override
    protected void insertFill(PreparedStatement s) throws SQLException {
        s.setBigDecimal(1, suma);
        s.setBigDecimal(2, sumaTrans);
        s.setBoolean(3, aktivny);
        s.setDate(4, datumVytvorenia);
        s.setInt(5, zakaznikId);
        s.setInt(6, menaId);
        s.setString(7, typ);
        s.setBigDecimal(8, urok);
        s.setDate(9, getDobaViazanosti());
        if (prepojenie == null) {
            s.setNull(10, Types.INTEGER);
        }
        else{
            s.setInt(10, prepojenie);
        }
    }

    public void insert() throws SQLException{
        insert("INSERT INTO ucty (suma, sumatrans, aktivny, datumVytvorenia, " +
                "zakaznikId, menaId, typ, urok, dobaViazanosti, prepojenie) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    }

    @Override
    protected void insertUpdateKeys(ResultSet r) throws SQLException {

    }

    @Override
    protected void updateFill(PreparedStatement s) throws SQLException {
        s.setBigDecimal(1, suma);
        s.setBigDecimal(2, sumaTrans);
        s.setBoolean(3, aktivny);
        s.setInt(4, id);
    }

    public void update() throws SQLException{
        update("UPDATE ucty SET suma = ?, sumaTrans = ?, aktivny = ?  WHERE id = ?");
    }

    @Override
    protected void deleteFill(PreparedStatement s) throws SQLException {

    }
}
