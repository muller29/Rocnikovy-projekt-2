package sk.uniba.fmph.simko.db2.application.rdg;

import sk.uniba.fmph.simko.db2.application.DbContext;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author Konád Müller
 */


public class UcetFinder extends BaseFinder{

    private static final UcetFinder INSTANCE = new UcetFinder();

    public static UcetFinder getInstance() {
        return INSTANCE;
    }

    private UcetFinder() {
    }

    public List<Ucet> findAllByZakaznikId(Integer zid) throws SQLException {
        return findAllByInt("SELECT * FROM ucty WHERE zakaznikId = ?", zid);
    }

    public List<Ucet> findAllAccounts(Integer zId, String typ) throws SQLException {
        return findAllByIntAndString("SELECT * FROM ucty WHERE zakaznikId = ? AND typ = ?", zId, typ);
    }

    public Ucet findById(Integer id) throws SQLException{
        return (Ucet) findByInt("SELECT * FROM ucty WHERE id = ?", id);
    }

    public List<Ucet> findAllUsedToday() throws SQLException {
        return findAll("SELECT * FROM ucty WHERE id IN " +
                "(SELECT ucetID FROM transakcie t WHERE datum = current_date)");
    }

    public List<Ucet> findAllActive() throws SQLException {
        return findAll("SELECT * FROM ucty WHERE aktivny IS TRUE");
    }

    public List<Ucet> findAllSavingAccByCurrentId(Integer id) throws SQLException {
        return findAllByInt("SELECT * FROM ucty WHERE typ = 'sporiaci' AND prepojenie = ?", id);
    }

    @Override
    protected Object load(ResultSet r) throws SQLException {
        Ucet u = new Ucet();

        u.setId(r.getInt("id"));
        u.setSuma(r.getBigDecimal("suma"));
        u.setSumaTrans(r.getBigDecimal("sumaTrans"));
        u.setAktivny(r.getBoolean("aktivny"));
        u.setDatumVytvorenia(r.getDate("datumVytvorenia"));
        u.setZakaznikId(r.getInt("zakaznikId"));
        u.setMenaId(r.getInt("menaId"));
        u.setTyp(r.getString("typ"));
        u.setUrok(r.getBigDecimal("urok"));
        u.setDobaViazanosti(r.getDate("dobaViazanosti"));
        u.setPrepojenie(r.getInt("prepojenie"));

        return u;
    }
}
