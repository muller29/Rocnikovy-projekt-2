package sk.uniba.fmph.simko.db2.application.rdg;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.*;

import sk.uniba.fmph.simko.db2.application.DbContext;


/**
 *
 * @author Konrád Müller
 */


public class Zakaznik extends BaseGateway {

    private Integer id;
    private String meno;
    private String priezvisko;
    private Long rodneCislo;
    private boolean aktivny;
    private Date datumEvidencii;
    private Date datumDeaktivovania;
    private Date datumAktivovania;

    public void resetDatumAktivovania(){
        datumAktivovania = null;
    }

    public Integer getId() {
        return id;
    }

    public String getMeno() {
        return meno;
    }

    public String getPriezvisko() {
        return priezvisko;
    }

    public Long getRodneCislo() {
        return rodneCislo;
    }

    public Boolean getAktivny() {
        return aktivny;
    }

    public Date getDatumEvidencii() {
        return datumEvidencii;
    }

    public Date getDatumDeaktivovania() {
        return datumDeaktivovania;
    }

    public Date getDatumAktivovania() {
        return datumAktivovania;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setMeno(String meno) {
        this.meno = meno;
    }

    public void setPriezvisko(String priezvisko) {
        this.priezvisko = priezvisko;
    }

    public void setRodneCislo(Long rodneCislo) {
        this.rodneCislo = rodneCislo;
    }

    public void setAktivny(Boolean aktivny) {
        this.aktivny = aktivny;
    }

    public void setDatumEvidencii(Date datumEvidencii) {
        this.datumEvidencii = datumEvidencii;
    }

    public void setDatumDeaktivovania(Date datumDeaktivovania) {
        this.datumDeaktivovania = datumDeaktivovania;
    }

    public void setDatumAktivovania(Date datumAktivovania) {
        this.datumAktivovania = datumAktivovania;
    }

    public void insert() throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("INSERT INTO zakaznici(meno, priezvisko, rodnecislo, aktivny, datumevidencii, datumdeaktivovania, datumaktivovania) VALUES (?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            s.setString(1, meno);
            s.setString(2, priezvisko);
            s.setLong(3, rodneCislo);
            s.setBoolean(4, aktivny);
            s.setDate(5, datumEvidencii);
            s.setDate(6, datumDeaktivovania);
            s.setDate(7, datumAktivovania);

            s.executeUpdate();

            try (ResultSet r = s.getGeneratedKeys()) {
                r.next();
                id = r.getInt(1);
            }
        }
    }


    @Override
    protected void insertFill(PreparedStatement s) throws SQLException {
        s.setString(1, meno);
        s.setString(2, priezvisko);
        s.setLong(3, rodneCislo);
        s.setBoolean(4, aktivny);
        s.setDate(5, datumEvidencii);
        s.setDate(6, datumDeaktivovania);
        s.setDate(7, datumAktivovania);
    }

    @Override
    protected void insertUpdateKeys(ResultSet r) throws SQLException {

    }

    public void update() throws SQLException {
        update("UPDATE zakaznici SET meno = ?, priezvisko = ?, aktivny = ?, datumDeaktivovania = ?, datumAktivovania = ? WHERE id = ?");
    }

    @Override
    protected void updateFill(PreparedStatement s) throws SQLException {
        s.setString(1, meno);
        s.setString(2, priezvisko);
        s.setBoolean(3, aktivny);
        s.setDate(4, datumDeaktivovania);
        s.setDate(5, datumAktivovania);
        s.setInt(6, id);
    }

    @Override
    protected void deleteFill(PreparedStatement s) throws SQLException {

    }
}
