package sk.uniba.fmph.simko.db2.application.rdg;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import sk.uniba.fmph.simko.db2.application.DbContext;


/**
 *
 * @author Konrád Müller
 */


public class ZakaznikFinder extends BaseFinder{

    private static final ZakaznikFinder INSTANCE = new ZakaznikFinder();

    public static ZakaznikFinder getInstance() {
        return INSTANCE;
    }

    private ZakaznikFinder() {
    }

    public Zakaznik findByRodnecislo(Long rc) throws SQLException {
        return (Zakaznik) findByLong("SELECT * FROM zakaznici WHERE rodneCislo = ?", rc);
    }

    public Zakaznik findById(Integer Id) throws SQLException {
        return (Zakaznik) findByInt("SELECT * FROM zakaznici WHERE id = ?", Id);
    }

    public List<Zakaznik> findAll() throws SQLException {
        return findAll("SELECT * FROM zakaznici");
    }

    @Override
    protected Zakaznik load(ResultSet r) throws SQLException {
        Zakaznik z = new Zakaznik();
        z.setId(r.getInt("id"));
        z.setMeno(r.getString("meno"));
        z.setPriezvisko(r.getString("priezvisko"));
        z.setRodneCislo(r.getLong("rodneCislo"));
        z.setAktivny(r.getBoolean("aktivny"));
        z.setDatumEvidencii(r.getDate("datumEvidencii"));
        z.setDatumDeaktivovania(r.getDate("datumDeaktivovania"));
        z.setDatumAktivovania(r.getDate("datumAktivovania"));

        return z;
    }
}
