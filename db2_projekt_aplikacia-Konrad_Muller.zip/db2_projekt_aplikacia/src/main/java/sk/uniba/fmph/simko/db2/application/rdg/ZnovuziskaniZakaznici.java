package sk.uniba.fmph.simko.db2.application.rdg;


/**
 *
 * @author Konád Müller
 */


public class ZnovuziskaniZakaznici{

    private Integer rokZnovuAkt;
    private int dobaDeakt;
    private int zCount;

    public Integer getRokZnovuAkt() {
        return rokZnovuAkt;
    }

    public void setRokZnovuAkt(Integer rokZnovuAkt) {
        this.rokZnovuAkt = rokZnovuAkt;
    }

    public int getDobaDeakt() {
        return dobaDeakt;
    }

    public void setDobaDeakt(int dobaDeakt) {
        this.dobaDeakt = dobaDeakt;
    }

    public int getzCount() {
        return zCount;
    }

    public void setzCount(int zCount) {
        this.zCount = zCount;
    }
}
