package sk.uniba.fmph.simko.db2.application.rdg;

import sk.uniba.fmph.simko.db2.application.DbContext;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author Konád Müller
 */


public class ZnovuziskaniZakazniciFinder {

    private static final ZnovuziskaniZakazniciFinder INSTANCE = new ZnovuziskaniZakazniciFinder();

    public static ZnovuziskaniZakazniciFinder getInstance() {
        return INSTANCE;
    }

    private ZnovuziskaniZakazniciFinder(){

    }

    public ZnovuziskaniZakaznici NumberOfZnovuziskaniZakaznici(Integer rokZnovuAkt, int dobaDeakt) throws SQLException {
        String sql = "SELECT count(*) as pocet " +
                "                FROM zakaznici WHERE aktivny IS TRUE AND datumAktivovania IS NOT NULL " +
                "                AND datumDeaktivovania IS NOT NULL " +
                "                AND EXTRACT(YEAR FROM datumAktivovania) = ? " +
                "                AND (EXTRACT(YEAR FROM datumAktivovania)-EXTRACT(YEAR FROM datumDeaktivovania)) = ?";

        try (PreparedStatement s = DbContext.getConnection().prepareStatement(sql)) {
            s.setInt(1, rokZnovuAkt);
            s.setInt(2, dobaDeakt);

            try (ResultSet r = s.executeQuery()) {

                if (r.next()){
                    ZnovuziskaniZakaznici z = new ZnovuziskaniZakaznici();
                    z.setzCount(r.getInt("pocet"));

                    if (r.next()){
                        throw new RuntimeException("More than one row was returned");
                    }

                    return z;
                }
                else{
                    return null;
                }
            }
        }
    }


}
