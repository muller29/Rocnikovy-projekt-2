package sk.uniba.fmph.simko.db2.application.ts;


/**
 *
 * @author Konád Müller
 */


public class FunkcieException extends Exception {

    FunkcieException(String message) {
        super(message);
    }

}