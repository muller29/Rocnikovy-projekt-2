package sk.uniba.fmph.simko.db2.application.ts;

import sk.uniba.fmph.simko.db2.application.DbContext;
import sk.uniba.fmph.simko.db2.application.rdg.*;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.text.Bidi;
import java.util.Calendar;
import java.util.List;


/**
 *
 * @author Konád Müller
 */


public class ZlozitejsieDomenoveOperacie {

    private static final ZlozitejsieDomenoveOperacie INSTANCE = new ZlozitejsieDomenoveOperacie();

    public static ZlozitejsieDomenoveOperacie getINSTANCE() {
        return INSTANCE;
    }

    public void zakDeaktivovanie(Integer id) throws SQLException, FunkcieException {
        //megnezni
        DbContext.getConnection().setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
        DbContext.getConnection().setAutoCommit(false);

        Zakaznik z = ZakaznikFinder.getInstance().findById(id);

        try{
            if (z == null){
                throw new FunkcieException("Zakaznik s danym id neexistuje");
            }
            else if (z.getAktivny() == false){
                throw new FunkcieException("Zakaznik uz nebol aktivny");
            }
            else{
                List<Ucet> ucty = UcetFinder.getInstance().findAllByZakaznikId(id);
                for(Ucet u : ucty){
                    if (u.getSuma() != BigDecimal.ZERO || u.getSumaTrans() != BigDecimal.ZERO){
                        throw new FunkcieException("Zakaznik este ma peniaze na niektorom ucte");
                    }
                }
                for (Ucet u : ucty){
                    u.setAktivny(false);
                    u.update();
                }
                java.sql.Date d = new java.sql.Date(Calendar.getInstance().getTime().getTime());
                z.setDatumDeaktivovania(d);
                z.resetDatumAktivovania();
                z.setAktivny(false);
                z.update();
                DbContext.getConnection().commit();
            }
        }catch (FunkcieException | SQLException e){
            DbContext.getConnection().rollback();
            throw e;
        } finally {
            DbContext.getConnection().setAutoCommit(true);
        }
    }

    public void dailyClosure() throws SQLException {
        DbContext.getConnection().setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
        DbContext.getConnection().setAutoCommit(false);

        List<Ucet> ucty = UcetFinder.getInstance().findAllUsedToday();

        try{
            for (Ucet u : ucty){
                BigDecimal zostatok = u.getSuma();
                BigDecimal trans = u.getSumaTrans();

                if(!zostatok.equals(trans)){
                    u.setSuma(trans);
                    u.update();
                }
            }
            DbContext.getConnection().commit();
        } catch (SQLException e){
            DbContext.getConnection().rollback();
            throw e;
        } finally {
            DbContext.getConnection().setAutoCommit(true);
        }
    }

    public void monthlyClosure() throws SQLException {
        DbContext.getConnection().setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
        DbContext.getConnection().setAutoCommit(false);

        List<Ucet> ucty = UcetFinder.getInstance().findAllActive();

        try{
            for (Ucet u : ucty){
                BigDecimal zostatok = u.getSumaTrans();
                BigDecimal taxes = new BigDecimal(TransakciaFinder.getInstance().findAllTaxTransByAccountId(u.getId()).size() * 3);
                BigDecimal realTrans = zostatok.subtract(taxes);

                if(!zostatok.equals(u.getSuma())){
                    u.setSuma(realTrans);
                    u.setSumaTrans(realTrans);
                }

                if(!taxes.equals(BigDecimal.ZERO)){
                    Transakcia t = new Transakcia();

                    t.setUcetId(u.getId());
                    t.setSuma(taxes);
                    t.setDatum(new java.sql.Date(Calendar.getInstance().getTime().getTime()));
                    t.setTyp("poplatok");

                    t.insert();
                }

                if(u.getTyp().equals("sporiaci") ||
                        (u.getTyp().equals("terminovany") &&
                                u.getDobaViazanosti().compareTo(new java.sql.Date(Calendar.getInstance().getTime().getTime())) > 0)){
                    BigDecimal urokSuma = new BigDecimal(u.getSuma().doubleValue() * (u.getUrok().doubleValue() / 100)
                            + u.getSuma().doubleValue());
                    u.setSuma(urokSuma);
                    u.setSumaTrans(urokSuma);
                    if(u.getId() == 1419){
                        System.out.println("if");
                    }
                }
                else if (u.getTyp().equals("terminovany") &&
                        u.getDobaViazanosti().compareTo(new java.sql.Date(Calendar.getInstance().getTime().getTime())) <= 0){
                    if(u.getSuma().equals(BigDecimal.ZERO)){
                        u.setAktivny(false);
                    }
                    if(u.getId() == 1419){
                        System.out.println("else if");
                    }
                }

                u.update();

            }

            DbContext.getConnection().commit();
        } catch (SQLException e){
            DbContext.getConnection().rollback();
            throw e;
        } finally {
            DbContext.getConnection().setAutoCommit(true);
        }
    }

    public void deaktAcoount(Integer uId) throws SQLException, FunkcieException {
        DbContext.getConnection().setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
        DbContext.getConnection().setAutoCommit(false);

        Ucet u = UcetFinder.getInstance().findById(uId);

        try{
            if (u == null){
                throw new FunkcieException("Ucet s danym id neexistuje");
            }
            else if (u.getAktivny() == false){
                throw new FunkcieException("Ucet uz nebol aktivny");
            }
            else{
                if(u.getTyp().equals("terminovany")){
                    BigDecimal taxes = new BigDecimal(TransakciaFinder.getInstance().findAllTaxTransByAccountId(u.getId()).size() * 3);
                    if (u.getSumaTrans().equals(BigDecimal.ZERO)){
                        u.setAktivny(false);
                        u.setSuma(BigDecimal.ZERO);
                        u.update();
                    }
                    else if (!(u.getSumaTrans().equals(BigDecimal.ZERO)) && u.getSumaTrans().equals(taxes)){
                        Transakcia t = new Transakcia();

                        t.setUcetId(u.getId());
                        t.setSuma(taxes);
                        t.setDatum(new java.sql.Date(Calendar.getInstance().getTime().getTime()));
                        t.setTyp("poplatok");

                        t.insert();

                        u.setAktivny(false);
                        u.setSuma(BigDecimal.ZERO);
                        u.setSumaTrans(BigDecimal.ZERO);
                        u.update();
                    }
                    else {
                        throw new FunkcieException("Na ucte nie je nulovy zostatok");
                    }
                }
                else if (u.getTyp().equals("sporiaci")){
                    BigDecimal taxes = new BigDecimal(TransakciaFinder.getInstance().findAllTaxTransByAccountId(u.getId()).size() * 3);
                    if (u.getSumaTrans().equals(BigDecimal.ZERO)){
                        u.setAktivny(false);
                        u.setSuma(BigDecimal.ZERO);
                        u.update();
                    }
                    else if (!(u.getSumaTrans().equals(BigDecimal.ZERO)) && u.getSumaTrans().equals(taxes)){
                        Transakcia t = new Transakcia();

                        t.setUcetId(u.getId());
                        t.setSuma(taxes);
                        t.setDatum(new java.sql.Date(Calendar.getInstance().getTime().getTime()));
                        t.setTyp("poplatok");

                        t.insert();

                        u.setAktivny(false);
                        u.setSuma(BigDecimal.ZERO);
                        u.setSumaTrans(BigDecimal.ZERO);
                        u.update();
                    }
                    else{
                        Ucet prepojenie = UcetFinder.getInstance().findById(u.getPrepojenie());
                        prepojenie.setSuma(u.getSuma().add(prepojenie.getSuma()));
                        prepojenie.setSumaTrans(u.getSumaTrans().add(prepojenie.getSumaTrans()));

                        prepojenie.update();

                        u.setAktivny(false);
                        u.setSuma(BigDecimal.ZERO);
                        u.setSumaTrans(BigDecimal.ZERO);
                        u.update();
                    }
                }
                else if (u.getTyp().equals("bezny")) {
                    BigDecimal taxes = new BigDecimal(TransakciaFinder.getInstance().findAllTaxTransByAccountId(u.getId()).size() * 3);
                    if (u.getSumaTrans().equals(BigDecimal.ZERO) || u.getSumaTrans().equals(taxes)) {
                        List<Ucet> ucty = UcetFinder.getInstance().findAllSavingAccByCurrentId(u.getId());

                        for (Ucet spUcet : ucty){
                            BigDecimal taxesSp = new BigDecimal(TransakciaFinder.getInstance().findAllTaxTransByAccountId(spUcet.getId()).size() * 3);
                            if (!spUcet.getSumaTrans().equals(BigDecimal.ZERO) && !spUcet.getSumaTrans().equals(taxesSp)){
                                throw new FunkcieException("Prepojeny sporiaci ucet s id " + spUcet.getId() + " nema nulovy zostatok");
                            }
                        }

                        for (Ucet spUcet : ucty) {
                            BigDecimal taxesSp = new BigDecimal(TransakciaFinder.getInstance().findAllTaxTransByAccountId(spUcet.getId()).size() * 3);

                            if (!taxesSp.equals(BigDecimal.ZERO)) {
                                Transakcia t = new Transakcia();

                                t.setUcetId(spUcet.getId());
                                t.setSuma(taxes);
                                t.setDatum(new java.sql.Date(Calendar.getInstance().getTime().getTime()));
                                t.setTyp("poplatok");

                                t.insert();
                            }

                            spUcet.setAktivny(false);
                            spUcet.setSuma(BigDecimal.ZERO);
                            spUcet.setSumaTrans(BigDecimal.ZERO);
                            spUcet.update();
                        }

                        if (!taxes.equals(BigDecimal.ZERO)) {
                            Transakcia t = new Transakcia();

                            t.setUcetId(u.getId());
                            t.setSuma(taxes);
                            t.setDatum(new java.sql.Date(Calendar.getInstance().getTime().getTime()));
                            t.setTyp("poplatok");

                            t.insert();
                        }

                        u.setAktivny(false);
                        u.setSuma(BigDecimal.ZERO);
                        u.setSumaTrans(BigDecimal.ZERO);
                        u.update();
                    }
                    else{
                        throw new FunkcieException("Na ucte nie je nulovy zostatok");
                    }
                }

                DbContext.getConnection().commit();
            }
        }catch (FunkcieException | SQLException e){
            DbContext.getConnection().rollback();
            throw e;
        } finally {
            DbContext.getConnection().setAutoCommit(true);
        }
    }

    public void createTransfer(Ucet u, Integer puId, BigDecimal suma) throws SQLException, FunkcieException {
        DbContext.getConnection().setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
        DbContext.getConnection().setAutoCommit(false);

        Ucet protiucet = UcetFinder.getInstance().findById(puId);
        Date now = new java.sql.Date(Calendar.getInstance().getTime().getTime());
        boolean jespoplatena = false;
        String typ = "";

        try{
            if (u.getTyp().equals("sporiaci")){
                typ = "prevod-sporiaci";
                List<Transakcia> transakcie = TransakciaFinder.getInstance().findAllTransInCurrMonthByAcc(u.getId());
                if (transakcie.size() > 0){
                    jespoplatena = true;
                }
                Ucet prepjenie = UcetFinder.getInstance().findById(u.getPrepojenie());
                if (!prepjenie.getId().equals(puId)) {
                    throw new FunkcieException("Zo sporiaceho uctu sa daju prostriedky previest iba na bezny ucet, ktory je so sporiacim uctom prepojeny");
                }
            }
            if (u.getTyp().equals("terminovany")) {
                typ = "prevod-terminovany";
                if (u.getDobaViazanosti().compareTo(now) > 0){
                    throw new FunkcieException("Doba viazanosti na terminovanom ucte este nevyprsala");
                }
            }
            if (u.getTyp().equals("bezny")){
                typ = "prevod-bezny";
            }

            BigDecimal kurz = new BigDecimal("1");

            if (protiucet != null){
                if (protiucet.getTyp().equals("terminovany") && protiucet.getDobaViazanosti().compareTo(now) > 0){
                    throw new FunkcieException("Doba viazanosti na cielovom terminovanom ucte este nevyprsala");
                }
                if (!protiucet.getAktivny()){
                    throw new FunkcieException("Protiucet nie je aktivny");
                }
                if (!protiucet.getMenaId().equals(u.getMenaId())){
                    Kurz k = KurzFinder.getInstance().findByTwoInts(u.getMenaId(), protiucet.getMenaId());
                    if (k == null){
                        throw new FunkcieException("Kurz medzi menami uctov neexistuje");
                    }
                    else {
                        kurz = k.getKurz();
                    }
                }
            }
            BigDecimal taxes = new BigDecimal(TransakciaFinder.getInstance().findAllTaxTransByAccountId(u.getId()).size() * 3);
            if (jespoplatena){
                suma = suma.add(new BigDecimal("3"));
            }

            if (suma.compareTo((u.getSumaTrans().subtract(taxes))) > 0){
                throw new FunkcieException("Na ucte nie je dostatocna suma");
            }

            Transakcia t = new Transakcia();
            t.setUcetId(u.getId());
            t.setSuma(suma);
            t.setDatum(now);
            t.setTyp(typ);
            t.setCisloProtiuctu(puId);



            if (protiucet != null){
                Transakcia opT = new Transakcia();
                opT.setUcetId(puId);
                opT.setSuma(suma.multiply(kurz));
                opT.setDatum(now);
                opT.setTyp("prijem");
                opT.setCisloProtiuctu(u.getId());

                u.setSuma(u.getSuma().subtract(suma));

                protiucet.setSuma(protiucet.getSuma().add(suma));
                protiucet.setSumaTrans(protiucet.getSumaTrans().add(suma));

                if (jespoplatena){
                    protiucet.setSuma(protiucet.getSuma().subtract(new BigDecimal("3")));
                    protiucet.setSumaTrans(protiucet.getSumaTrans().subtract(new BigDecimal("3")));
                    t.setSuma(suma.subtract(new BigDecimal("3")));
                    opT.setSuma(suma.subtract(new BigDecimal("3")));
                }

                opT.insert();

                protiucet.update();
            }

            t.insert();

            u.setSumaTrans(u.getSumaTrans().subtract(suma));

            u.update();

            DbContext.getConnection().commit();
        } catch (FunkcieException | SQLException e){
            DbContext.getConnection().rollback();
            throw e;
        } finally {
            DbContext.getConnection().setAutoCommit(true);
        }

    }
}
