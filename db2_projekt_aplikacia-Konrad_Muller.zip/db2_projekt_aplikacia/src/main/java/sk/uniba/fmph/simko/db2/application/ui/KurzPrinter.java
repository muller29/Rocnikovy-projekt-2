package sk.uniba.fmph.simko.db2.application.ui;

import sk.uniba.fmph.simko.db2.application.rdg.Kurz;
import sk.uniba.fmph.simko.db2.application.rdg.Mena;
import sk.uniba.fmph.simko.db2.application.rdg.MenaFinder;

import java.sql.SQLException;


/**
 *
 * @author Konád Müller
 */


public class KurzPrinter {

    private static final KurzPrinter INSTANCE = new KurzPrinter();

    public static KurzPrinter getInstance() { return INSTANCE; }

    private KurzPrinter() { }

    public void print(Kurz k) throws SQLException {
        if (k == null) {
            throw new NullPointerException("Kurz nemoze byt null");
        }

        System.out.print("id:      ");
        System.out.println(k.getId());
        System.out.print("z meny:  ");
        Mena zm = MenaFinder.getInstance().findById(k.getzMeny());
        System.out.println(zm.getNazov());
        System.out.print("na menu: ");
        Mena nm = MenaFinder.getInstance().findById(k.getNaMenu());
        System.out.println(nm.getNazov());
        System.out.print("kurz:    ");
        System.out.println(k.getKurz());
        System.out.println();
    }
}
