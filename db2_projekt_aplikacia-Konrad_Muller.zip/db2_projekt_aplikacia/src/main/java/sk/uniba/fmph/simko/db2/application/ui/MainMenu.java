package sk.uniba.fmph.simko.db2.application.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.sql.Date;
import java.util.List;

import sk.uniba.fmph.simko.db2.application.rdg.*;
import sk.uniba.fmph.simko.db2.application.ts.ZlozitejsieDomenoveOperacie;
import sk.uniba.fmph.simko.db2.application.ts.FunkcieException;


/**
 *
 * @author Konrád Müller
 */


public class MainMenu extends Menu {

    @Override
    public void print() {
        System.out.println("****************************************************");
        System.out.println("* 1. Vypis zoznam zakaznikov                       *");
        System.out.println("* 2. Najdi zakaznika podla rodného čísla           *");
        System.out.println("* 3. Aktualizuj osobné udaje zákazníka             *");
        System.out.println("* 4. Deaktivuj zákazníka                           *");
        System.out.println("* 5. Vypíš znovuzískaných zákaznákov               *");
        System.out.println("* 6. Vypíš bežné účty zákazníka                    *");
        System.out.println("* 7. Zaloz novy bezny ucet                         *");
        System.out.println("* 8. Aktivuj deaktivovany bezny ucet               *");
        System.out.println("* 9. Vypíš sporiace účty zákazníka                 *");
        System.out.println("* 10. Zaloz novy sporiaci ucet                     *");
        System.out.println("* 11. Aktivuj deaktivovany sporiaci ucet           *");
        System.out.println("* 12. Vypíš terminovane účty zákazníka             *");
        System.out.println("* 13. Zaloz novy terminovany ucet                  *");
        System.out.println("* 14. Vypis zoznam prevodovych kurzov              *");
        System.out.println("* 15. Pridaj prevodovy kurz medzi dvoma menami     *");
        System.out.println("* 16. Aktualizuj prevodovy kurz medzi dvoma menami *");
        System.out.println("* 17. Zmaz prevodovy kurz medzi dvoma menami       *");
        System.out.println("* 18. Vypis zoznam transakcii nad danym uctom      *");
        System.out.println("* 19. Denna uzavierka                              *");
        System.out.println("* 20. Koncomesacna uzavierka                       *");
        System.out.println("* 21. Deaktivovanie uctu                           *");
        System.out.println("* 22. Prevod penazi medzi dvoma uctami             *");
        System.out.println("****************************************************");
    }

    @Override
    public void handle(String option) {
        try {
            switch (option) {
                case "1":   listAllCustomers(); break;
                case "2":   showACustomer(); break;
                case "3":   refreshACustomer(); break;
                case "4":   zakDeakt(); break;
                case "5":   printZnovuziskaniZakaznici(); break;
                case "6":   listCurrentAccounts(); break;
                case "7":   createCurrentAccount(); break;
                case "8":   activateCurrentAccount(); break;
                case "9":   listSavingAccounts(); break;
                case "10":  createSavingAccount(); break;
                case "11":  activateSavingAccount(); break;
                case "12":  listTermAccounts(); break;
                case "13":  createTermAccount(); break;
                case "14":  listAllExchangeRates(); break;
                case "15":  createExchangeRate(); break;
                case "16":  updateExchangeRate(); break;
                case "17":  deleteExchangeRate(); break;
                case "18":  listAllTransactions(); break;
                case "19":  dailyClosure(); break;
                case "20":  monthlyClosure(); break;
                case "21":  deaktAccount(); break;
                case "22":  createTransfer(); break;
                //case "23":   exit(); break;
                default:    System.out.println("Unknown option"); break;
            }
        } catch(SQLException | IOException e){//| InterruptedException e) {
            throw new RuntimeException(e);
        }

    }


    private void listAllCustomers() throws SQLException, IOException {
        List<Zakaznik> z = new ArrayList();
        z = ZakaznikFinder.getInstance().findAll();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int count = 0;

        System.out.println("Strana " + (count+1));
        for (int i = 0; i < 15; i++) {
            if (count*15+i >= z.size()){
                System.out.println("Vypisali ste vsetky strany");
                return;
            }
            Zakaznik zak = z.get(count*15+i);
            ZakaznikPrinter.getInstance().print(zak);
        }

        while (true){
            System.out.println("stlac N pre dalsiu, alebo P pre predchadzajucu stranu");
            String r = br.readLine().toString();
            if (r.equals("N") || r.equals("n")){
                count++;
                System.out.println("Strana " + (count+1));
                for (int i = 0; i < 15; i++) {
                    if (count*15+i >= z.size()){
                        System.out.println("Vypisali ste vsetky strany");
                        return;
                    }
                    Zakaznik zak = z.get(count*15+i);
                    ZakaznikPrinter.getInstance().print(zak);
                }
            }
            else if (r.equals("P") || r.equals("p")){
                count--;
                if (count < 0){
                    System.out.println("Nie je predchadzajuca strana");
                    return;
                }
                System.out.println("Strana" + (count+1));
                for (int i = 0; i < 15; i++) {
                    if (count*15+i >= z.size()){
                        System.out.println("Vypisali ste vsetky strany");
                        return;
                    }
                    Zakaznik zak = z.get(count*15+i);
                    ZakaznikPrinter.getInstance().print(zak);
                }

            }
            else {
                return;
            }
        }

    }

    private void showACustomer() throws IOException, SQLException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Zadaj rodne cislo zakaznika:");
        Long rc = Long.parseLong(br.readLine());

        Zakaznik z = ZakaznikFinder.getInstance().findByRodnecislo(rc);
        
        if (z == null) {
            System.out.println("Neexistuje zakaznik s danym rodnym cislom");
        } else {
            ZakaznikPrinter.getInstance().print(z);
        }

    }

    private void refreshACustomer() throws IOException, SQLException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Zadaj id zakaznika:");
        Integer zid = Integer.parseInt(br.readLine());

        Zakaznik z = ZakaznikFinder.getInstance().findById(zid);

        if (z == null) {
            System.out.println("Neexistuje zakaznik s danym id");
        } else {
            ZakaznikPrinter.getInstance().print(z);
            System.out.println("Zadaj meno: ");
            z.setMeno(br.readLine());
            System.out.println("Zadaj priezvisko: ");
            z.setPriezvisko(br.readLine());
            z.update();
            System.out.println("Zakaznik bol aktualizovany.");
        }
    }

    private void zakDeakt() throws IOException, SQLException {
        ZlozitejsieDomenoveOperacie f = ZlozitejsieDomenoveOperacie.getINSTANCE();

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Zadaj id zakaznika:");
        Integer zid = Integer.parseInt(br.readLine());

        try{
            f.zakDeaktivovanie(zid);
            System.out.println("Zakaznik bol uspesne deaktivovany");

        } catch (FunkcieException e) {
            System.out.println(e.getMessage());
        }

    }

    private void printZnovuziskaniZakaznici() throws SQLException, IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Zadaj rok znovuaktivovania:");
        Integer rokZnovuAkt = Integer.parseInt(br.readLine());

        System.out.println("Zadaj dobu po koľkých rokov sa vrátili zákazníci:");
        Integer dobaDeakt = Integer.parseInt(br.readLine());

        ZnovuziskaniZakaznici z = ZnovuziskaniZakazniciFinder.getInstance().NumberOfZnovuziskaniZakaznici(rokZnovuAkt, dobaDeakt);
        z.setRokZnovuAkt(rokZnovuAkt);
        z.setDobaDeakt(dobaDeakt);

        StatistikaPrinter.getInstance().print(z);
    }

    private void listCurrentAccounts() throws IOException, SQLException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Zadaj id zákazníka:");
        Integer zakId = Integer.parseInt(br.readLine());
        List<Ucet> ucty = UcetFinder.getInstance().findAllAccounts(zakId, "bezny");

        if(ucty == null || ucty.size() == 0){
            System.out.println("Tento zákazník nemá bežný účet");
        }
        else{
            for (Ucet u : ucty){
                UcetPrinter.getInstance().print(u);
            }
        }
    }

    private void createCurrentAccount() throws IOException, SQLException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Ucet u = new Ucet();

        System.out.println("Zadaj id zakaznika:");
        Integer zId = Integer.parseInt(br.readLine());
        Zakaznik z = ZakaznikFinder.getInstance().findById(zId);
        boolean trebaAktivovat = false;
        if(z == null){
            System.out.println("Zakaznik s danym id neexistuje");
            return;
        }
        else if (z.getAktivny() == false){
            trebaAktivovat = true;
        }

        System.out.println("Zadaj sumu:");
        BigDecimal suma = new BigDecimal(br.readLine());

        System.out.println("Zadaj id meny:");
        Integer menaId = Integer.parseInt(br.readLine());
        Mena m = MenaFinder.getInstance().findById(menaId);
        if (m == null){
            System.out.println("Mena s danym id neexistuje");
            return;
        }

        u.setSuma(suma);
        u.setSumaTrans(suma);
        u.setAktivny(true);
        u.setDatumVytvorenia(new java.sql.Date(Calendar.getInstance().getTime().getTime()));
        u.setZakaznikId(zId);
        u.setMenaId(menaId);
        u.setTyp("bezny");

        if (trebaAktivovat){
            z.setAktivny(true);
            z.setDatumAktivovania(new java.sql.Date(Calendar.getInstance().getTime().getTime()));
            z.update();
        }

        u.insert();
        System.out.println("Ucet bol uspesne vytvoreny");
    }

    private void activateCurrentAccount() throws IOException, SQLException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Zadaj id bezneho uctu:");
        Integer uId = Integer.parseInt(br.readLine());
        Ucet u = UcetFinder.getInstance().findById(uId);

        if (u == null){
            System.out.println("Ucet s danym id neexistuje");
            return;
        }
        else if (!u.getTyp().equals("bezny")){
            System.out.println("Dany ucet nie je bezny");
            return;
        }
        else if (u.getAktivny()){
            System.out.println("Dany ucet uz bol aktivny");
            return;
        }

        Zakaznik z = ZakaznikFinder.getInstance().findById(u.getZakaznikId());
        if (z.getAktivny() == false){
            z.setAktivny(true);
            z.setDatumAktivovania(new java.sql.Date(Calendar.getInstance().getTime().getTime()));
            z.update();
        }

        u.setAktivny(true);
        u.update();

        System.out.println("Ucet bol uspesne aktivovany");
    }


    private void listSavingAccounts() throws IOException, SQLException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Zadaj id zákazníka:");
        Integer zakId = Integer.parseInt(br.readLine());
        List<Ucet> ucty = UcetFinder.getInstance().findAllAccounts(zakId, "sporiaci");

        if(ucty == null || ucty.size() == 0){
            System.out.println("Tento zákazník nemá sporiaci účet");
        }
        else{
            for (Ucet u : ucty){
                UcetPrinter.getInstance().print(u);
            }
        }
    }

    private void createSavingAccount() throws IOException, SQLException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Ucet u = new Ucet();

        System.out.println("Zadaj id zakaznika:");
        Integer zId = Integer.parseInt(br.readLine());
        Zakaznik z = ZakaznikFinder.getInstance().findById(zId);
        if(z == null){
            System.out.println("Zakaznik s danym id neexistuje");
            return;
        }
        else if (z.getAktivny() == false){
            System.out.println("Zakaznik s danym id nie je aktivny");
            return;
        }

        System.out.println("Zadaj id bezneho uctu, s ktorym bude prepojeny");
        Integer prepojenie = Integer.parseInt(br.readLine());

        Ucet bezny = UcetFinder.getInstance().findById(prepojenie);
        if(bezny == null){
            System.out.println("Neexistuje bezny ucet s danym id");
            return;
        }
        else if(!bezny.getZakaznikId().equals(zId)){
            System.out.println("Zadany ucet nepatri danemu zakaznikovi");
            return;
        }
        else if (!bezny.getTyp().equals("bezny")){
            System.out.println("Zadany ucet nie je bezny");
            return;
        }
        else if (bezny.getAktivny() == false){
            System.out.println("Zadany bezny ucet nie je aktivny");
            return;
        }

        System.out.println("Zadaj sumu:");
        BigDecimal suma = new BigDecimal(br.readLine());

        System.out.println("Zadaj urok");
        BigDecimal urok = new BigDecimal(br.readLine());

        Integer menaId = bezny.getMenaId();

        u.setSuma(suma);
        u.setSumaTrans(suma);
        u.setAktivny(true);
        u.setDatumVytvorenia(new java.sql.Date(Calendar.getInstance().getTime().getTime()));
        u.setZakaznikId(zId);
        u.setMenaId(menaId);
        u.setTyp("sporiaci");
        u.setUrok(urok);
        u.setPrepojenie(prepojenie);

        u.insert();
        System.out.println("Ucet bol uspesne vytvoreny");
    }


    private void activateSavingAccount() throws IOException, SQLException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Zadaj id sporiaceho uctu:");
        Integer uId = Integer.parseInt(br.readLine());
        Ucet u = UcetFinder.getInstance().findById(uId);

        if (u == null){
            System.out.println("Ucet s danym id neexistuje");
            return;
        }
        else if (!u.getTyp().equals("sporiaci")){
            System.out.println("Dany ucet nie je sporiaci");
            return;
        }
        else if (u.getAktivny()){
            System.out.println("Dany ucet uz bol aktivny");
            return;
        }

        Ucet bezny = UcetFinder.getInstance().findById(u.getPrepojenie());

        if (!bezny.getAktivny()){
            System.out.println("Prepojeny bezny ucet nie je aktivny");
            return;
        }

        u.setAktivny(true);
        u.update();

        System.out.println("Ucet bol uspesne aktivovany");
    }


    private void listTermAccounts() throws IOException, SQLException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Zadaj id zákazníka:");
        Integer zakId = Integer.parseInt(br.readLine());
        List<Ucet> ucty = UcetFinder.getInstance().findAllAccounts(zakId, "terminovany");

        if(ucty == null || ucty.size() == 0){
            System.out.println("Tento zákazník nemá terminovany účet");
        }
        else{
            for (Ucet u : ucty){
                UcetPrinter.getInstance().print(u);
            }
        }
    }

    private void createTermAccount() throws IOException, SQLException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Ucet u = new Ucet();

        System.out.println("Zadaj id zakaznika:");
        Integer zId = Integer.parseInt(br.readLine());
        Zakaznik z = ZakaznikFinder.getInstance().findById(zId);
        boolean trebaAktivovat = false;
        if(z == null){
            System.out.println("Zakaznik s danym id neexistuje");
            return;
        }
        else if (z.getAktivny() == false){
            trebaAktivovat = true;
        }

        System.out.println("Zadaj sumu:");
        BigDecimal suma = new BigDecimal(br.readLine());

        System.out.println("Zadaj id meny:");
        Integer menaId = Integer.parseInt(br.readLine());
        Mena m = MenaFinder.getInstance().findById(menaId);
        if (m == null){
            System.out.println("Mena s danym id neexistuje");
            return;
        }

        Date dnes = new java.sql.Date(Calendar.getInstance().getTime().getTime());
        System.out.println("Zadaj dobu viazanosti vo forme yyyy-MM-dd");
        java.util.Date dobaViazanosti0 = new java.util.Date();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try {
            dobaViazanosti0 = (java.util.Date) (df.parse(br.readLine()));
        } catch (ParseException e) {
            System.out.println("Datum nie je v korektnej forme");
        }
        Date dobaViazanosti = new java.sql.Date(dobaViazanosti0.getTime());
        if (dobaViazanosti.compareTo(dnes) < 0){
            System.out.println("Doba viazanosti musi byt vacsi ako dnesny datum");
            return;
        }

        System.out.println("Zadaj urok");
        BigDecimal urok = new BigDecimal(br.readLine());

        u.setSuma(suma);
        u.setSumaTrans(suma);
        u.setAktivny(true);
        u.setDatumVytvorenia(dnes);
        u.setDobaViazanosti(dobaViazanosti);
        u.setZakaznikId(zId);
        u.setMenaId(menaId);
        u.setTyp("terminovany");
        u.setUrok(urok);

        if (trebaAktivovat){
            z.setAktivny(true);
            z.setDatumAktivovania(new java.sql.Date(Calendar.getInstance().getTime().getTime()));
            z.update();
        }

        u.insert();
        System.out.println("Ucet bol uspesne vytvoreny");
    }

    public void listAllExchangeRates() throws SQLException, IOException {
        List<Kurz> k = new ArrayList();
        k = KurzFinder.getInstance().findAll();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int count = 0;

        System.out.println("Strana " + (count+1));
        for (int i = 0; i < 15; i++) {
            if (count*15+i >= k.size()){
                System.out.println("Vypisali ste vsetky strany");
                return;
            }
            Kurz kurz = k.get(count*15+i);
            KurzPrinter.getInstance().print(kurz);
        }

        while (true){
            System.out.println("stlac N pre dalsiu, alebo P pre predchadzajucu stranu");
            String r = br.readLine().toString();
            if (r.equals("N") || r.equals("n")){
                count++;
                System.out.println("Strana " + (count+1));
                for (int i = 0; i < 15; i++) {
                    if (count*15+i >= k.size()){
                        System.out.println("Vypisali ste vsetky strany");
                        return;
                    }
                    Kurz kurz = k.get(count*15+i);
                    KurzPrinter.getInstance().print(kurz);
                }
            }
            else if (r.equals("P") || r.equals("p")){
                count--;
                if (count < 0){
                    System.out.println("Nie je predchadzajuca strana");
                    return;
                }
                System.out.println("Strana" + (count+1));
                for (int i = 0; i < 15; i++) {
                    if (count*15+i >= k.size()){
                        System.out.println("Vypisali ste vsetky strany");
                        return;
                    }
                    Kurz kurz = k.get(count*15+i);
                    KurzPrinter.getInstance().print(kurz);
                }

            }
            else {
                return;
            }
        }
    }

    public void createExchangeRate() throws IOException, SQLException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Kurz k = new Kurz();

        System.out.println("Zadaj id meny z ktorej bude vymena:");
        Integer m1Id = Integer.parseInt(br.readLine());
        Mena m1 = MenaFinder.getInstance().findById(m1Id);

        if(m1 == null){
            System.out.println("Mena s takym id neexistuje");
            return;
        }

        System.out.println("Zadaj id meny na ktoru bude vymena:");
        Integer m2Id = Integer.parseInt(br.readLine());
        Mena m2 = MenaFinder.getInstance().findById(m2Id);

        if (m2 == null){
            System.out.println("Mena s takym id neexistuje");
            return;
        }

        if (m1Id == m2Id){
            System.out.println("Zadane dve meny su tie iste");
            return;
        }

        Kurz tmpKurz = KurzFinder.getInstance().findByTwoInts(m1Id, m2Id);
        if (tmpKurz != null){
            System.out.println("Kurz na tieto meny uz existuje");
            return;
        }

        System.out.println("Zadaj kurz:");
        BigDecimal kurz = new BigDecimal(br.readLine());

        k.setKurz(kurz);
        k.setzMeny(m1Id);
        k.setNaMenu(m2Id);

        k.insert();

        System.out.println("Kurz bol uspesne vytvoreny");

    }

    public void updateExchangeRate() throws IOException, SQLException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Zadaj id kurzu:");
        Integer kId = Integer.parseInt(br.readLine());

        Kurz k = KurzFinder.getInstance().findById(kId);
        if (k == null){
            System.out.println("Kurz s danym id neexistuje");
            return;
        }

        System.out.println("Zadaj kurz:");
        BigDecimal kurz = new BigDecimal(br.readLine());

        k.setKurz(kurz);

        k.update();

        System.out.println("Kurz bol uspesne aktualizovany");
    }

    public void deleteExchangeRate() throws IOException, SQLException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Zadaj id kurzu:");
        Integer kId = Integer.parseInt(br.readLine());

        Kurz k = KurzFinder.getInstance().findById(kId);
        if (k == null){
            System.out.println("Kurz s danym id neexistuje");
            return;
        }

        k.delete();

        System.out.println("Kurz bol uspesne vymazany");
    }

    public void listAllTransactions() throws IOException, SQLException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Zadaj id uctu:");
        Integer uId = Integer.parseInt(br.readLine());

        Ucet u = UcetFinder.getInstance().findById(uId);

        if(u == null){
            System.out.println("Ucet s danym id neexistuje");
            return;
        }

        List<Transakcia> t = new ArrayList();
        t = TransakciaFinder.getInstance().findAllByAccountId(uId);
        int count = 0;

        System.out.println("Strana " + (count+1));
        for (int i = 0; i < 15; i++) {
            if (count*15+i >= t.size()){
                System.out.println("Vypisali ste vsetky strany");
                return;
            }
            Transakcia trans = t.get(count*15+i);
            TransakciaPrinter.getInstance().print(trans);
        }

        while (true){
            System.out.println("stlac N pre dalsiu, alebo P pre predchadzajucu stranu");
            String r = br.readLine().toString();
            if (r.equals("N") || r.equals("n")){
                count++;
                System.out.println("Strana " + (count+1));
                for (int i = 0; i < 15; i++) {
                    if (count*15+i >= t.size()){
                        System.out.println("Vypisali ste vsetky strany");
                        return;
                    }
                    Transakcia trans = t.get(count*15+i);
                    TransakciaPrinter.getInstance().print(trans);
                }
            }
            else if (r.equals("P") || r.equals("p")){
                count--;
                if (count < 0){
                    System.out.println("Nie je predchadzajuca strana");
                    return;
                }
                System.out.println("Strana" + (count+1));
                for (int i = 0; i < 15; i++) {
                    if (count*15+i >= t.size()){
                        System.out.println("Vypisali ste vsetky strany");
                        return;
                    }
                    Transakcia trans = t.get(count*15+i);
                    TransakciaPrinter.getInstance().print(trans);
                }

            }
            else {
                return;
            }
        }
    }

    public void dailyClosure() throws SQLException {
        ZlozitejsieDomenoveOperacie f = ZlozitejsieDomenoveOperacie.getINSTANCE();

        f.dailyClosure();
        System.out.println("Denna uzavierka bola uspesne vykonana");
    }

    public void monthlyClosure() throws SQLException {
        ZlozitejsieDomenoveOperacie f = ZlozitejsieDomenoveOperacie.getINSTANCE();

        f.monthlyClosure();
        System.out.println("Koncomesacna uzavierka bola uspesne vykonana");
    }

    private void deaktAccount() throws IOException, SQLException {
        ZlozitejsieDomenoveOperacie f = ZlozitejsieDomenoveOperacie.getINSTANCE();

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Zadaj id uctu:");
        Integer uId = Integer.parseInt(br.readLine());


        try{
            f.deaktAcoount(uId);
            System.out.println("Ucet bol uspesne deaktivovany");

        } catch (FunkcieException e) {
            System.out.println(e.getMessage());
        }
    }

    private void createTransfer() throws IOException, SQLException {
        ZlozitejsieDomenoveOperacie f = ZlozitejsieDomenoveOperacie.getINSTANCE();

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Zadaj id uctu:");
        Integer uId = Integer.parseInt(br.readLine());
        Ucet u = UcetFinder.getInstance().findById(uId);
        if (u == null){
            System.out.println("Ucet s danym id neexistuje");
            return;
        }
        if (!u.getAktivny()){
            System.out.println("Ucet s danym id nie je aktivny");
            return;
        }

        System.out.println("Zadaj id protiuctu:");
        Integer puId = Integer.parseInt(br.readLine());
        if (uId.equals(puId)){
            System.out.println("Id uctu sa rovna id protiuctu");
            return;
        }

        System.out.println("Zadaj sumu:");
        BigDecimal suma = new BigDecimal(br.readLine());

        try {
            f.createTransfer(u, puId, suma);
            System.out.println("Transakcia bola uspesne vytvorena");
        } catch (FunkcieException e) {
            System.out.println(e.getMessage());
        }
    }

    
}