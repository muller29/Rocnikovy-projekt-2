package sk.uniba.fmph.simko.db2.application.ui;

import sk.uniba.fmph.simko.db2.application.rdg.ZnovuziskaniZakaznici;


/**
 *
 * @author Konád Müller
 */


public class StatistikaPrinter {

    private static final StatistikaPrinter INSTANCE = new StatistikaPrinter();

    public static StatistikaPrinter getInstance(){
        return INSTANCE;
    }

    private StatistikaPrinter(){

    }

    public void print(ZnovuziskaniZakaznici z){
        if (z == null){
            throw new NullPointerException("Statistika nemoze byt null");
        }
        System.out.print("datum aktivovania: ");
        System.out.println(z.getRokZnovuAkt());
        System.out.print("vratil po:         ");
        System.out.println(z.getDobaDeakt() + " rokov");
        System.out.print("pocet:             ");
        System.out.println(z.getzCount());
    }

}
