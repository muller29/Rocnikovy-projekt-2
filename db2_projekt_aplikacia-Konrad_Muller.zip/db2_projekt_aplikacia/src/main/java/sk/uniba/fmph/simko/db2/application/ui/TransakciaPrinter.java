package sk.uniba.fmph.simko.db2.application.ui;

import sk.uniba.fmph.simko.db2.application.rdg.Transakcia;

import java.sql.SQLException;


/**
 *
 * @author Konád Müller
 */


public class TransakciaPrinter {

    private static final TransakciaPrinter INSTANCE = new TransakciaPrinter();

    public static TransakciaPrinter getInstance() { return INSTANCE; }

    private TransakciaPrinter() { }

    public void print(Transakcia t) throws SQLException {
        if (t == null) {
            throw new NullPointerException("Transakcia nemoze byt null");
        }
        System.out.println("id transakcie:   " + t.getId());
        System.out.println("id uctu:         " + t.getUcetId());
        System.out.println("id karty:        " + t.getKartaId());
        System.out.println("suma:            " + t.getSuma());
        System.out.println("datum:           " + t.getDatum());
        System.out.println("typ:             " + t.getTyp());
        System.out.println("cislo protiucty: " + t.getCisloProtiuctu());

        System.out.println();
    }
}
