package sk.uniba.fmph.simko.db2.application.ui;

import sk.uniba.fmph.simko.db2.application.rdg.Mena;
import sk.uniba.fmph.simko.db2.application.rdg.MenaFinder;
import sk.uniba.fmph.simko.db2.application.rdg.Ucet;

import java.sql.SQLException;


/**
 *
 * @author Konád Müller
 */


public class UcetPrinter {

    private static final UcetPrinter INSTANCE = new UcetPrinter();

    public static UcetPrinter getInstance() { return INSTANCE; }

    private UcetPrinter() { }

    public void print(Ucet u) throws SQLException {
        if (u == null) {
            throw new NullPointerException("Ucet nemoze byt null");
        }
        System.out.println("id uctu:          " + u.getId());
        System.out.println("suma na ucte:     " + u.getSuma());
        System.out.println("aktivny:          " + ((u.getAktivny()) ? "Ano" : "Nie"));
        System.out.println("datum vytvorenia: " + u.getDatumVytvorenia());
        Mena m = MenaFinder.getInstance().findById(u.getMenaId());
        System.out.println("mena:             " + m.getNazov());

        if (u.getTyp().equals("sporiaci")){
            System.out.println("id prepojenia:    " + u.getPrepojenie());
        }

        if (u.getTyp().equals("terminovany")){
            System.out.println("doba viazanosti:  " + u.getDobaViazanosti());
        }

        System.out.println();
    }
}
