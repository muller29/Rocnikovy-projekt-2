package sk.uniba.fmph.simko.db2.application.ui;

import sk.uniba.fmph.simko.db2.application.rdg.Zakaznik;


/**
 *
 * @author Konád Müller
 */


public class ZakaznikPrinter {


    private static final ZakaznikPrinter INSTANCE = new ZakaznikPrinter();

    public static ZakaznikPrinter getInstance() { return INSTANCE; }

    private ZakaznikPrinter() { }

    public void print(Zakaznik z) {
        if (z == null) {
            throw new NullPointerException("Zakaznik nemoze byt null");
        }

        System.out.print("id:                  ");
        System.out.println(z.getId());
        System.out.print("meno:                ");
        System.out.println(z.getMeno());
        System.out.print("priezvisko:          ");
        System.out.println(z.getPriezvisko());
        System.out.print("rodne cislo:         ");
        System.out.println(z.getRodneCislo());
        System.out.print("aktivny:             ");
        System.out.println(z.getAktivny());
        System.out.print("datum evidencii:     ");
        System.out.println(z.getDatumEvidencii());
        System.out.print("datum deaktivovania: ");
        System.out.println(z.getDatumDeaktivovania());
        System.out.print("datum aktivovania:   ");
        System.out.println(z.getDatumAktivovania());
        System.out.println();
    }
}
