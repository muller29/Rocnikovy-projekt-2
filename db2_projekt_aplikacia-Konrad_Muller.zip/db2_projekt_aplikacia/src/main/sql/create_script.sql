/**
 * @author:  Konrád Müller
 */


drop table if exists zakaznici cascade;
create table zakaznici (
  id                 SERIAL PRIMARY KEY,
  meno               VARCHAR NOT NULL,
  priezvisko         VARCHAR NOT NULL,
  rodneCislo         BIGINT UNIQUE NOT NULL,
  aktivny            BOOLEAN NOT NULL,
  datumEvidencii     DATE NOT NULL,
  datumDeaktivovania DATE,
  datumAktivovania   DATE
);

DROP TABLE IF EXISTS ucty CASCADE;
CREATE TABLE ucty (
  id              SERIAL PRIMARY KEY,
  suma            NUMERIC NOT NULL CHECK (suma >= 0),
  sumaTrans       NUMERIC CHECK (sumaTrans >= 0),
  aktivny         BOOLEAN NOT NULL,
  datumVytvorenia DATE NOT NULL,
  zakaznikId      INTEGER REFERENCES zakaznici ON DELETE CASCADE NOT NULL,
  menaId          INTEGER REFERENCES meny ON DELETE CASCADE NOT NULL,
  typ             VARCHAR CHECK (typ in ('bezny', 'sporiaci', 'terminovany')) NOT NULL,

  --terminovany
  urok            NUMERIC, --aj sporiaci
  dobaViazanosti  DATE,

  --sporiaci
  prepojenie      INTEGER REFERENCES ucty
);

DROP TABLE IF EXISTS meny CASCADE ;
CREATE TABLE meny (
  id    SERIAL PRIMARY KEY,
  nazov VARCHAR NOT NULL
);

ALTER TABLE ucty ADD FOREIGN KEY (menaId) REFERENCES meny;

DROP TABLE IF EXISTS kurzy CASCADE;
CREATE TABLE kurzy (
  id     SERIAL PRIMARY KEY,
  kurz   NUMERIC NOT NULL,
  zMeny  INTEGER REFERENCES meny ON DELETE CASCADE NOT NULL,
  naMenu INTEGER REFERENCES meny ON DELETE CASCADE NOT NULL
);

DROP TABLE IF EXISTS platobneKarty CASCADE;
CREATE TABLE platobneKarty (
  id     SERIAL PRIMARY KEY,
  kod    INTEGER NOT NULL,
  ucetId INTEGER REFERENCES ucty ON DELETE CASCADE NOT NULL
);

DROP TABLE IF EXISTS transakcie CASCADE;
CREATE TABLE transakcie (
  id             SERIAL PRIMARY KEY,
  ucetId         INTEGER REFERENCES ucty ON DELETE CASCADE,
  kartaId        INTEGER REFERENCES platobneKarty ON DELETE CASCADE,
  suma           NUMERIC NOT NULL,
  datum          DATE NOT NULL,
  typ            VARCHAR CHECK (typ in ('vyber-kartou', 'vyber-hotovost', 'prevod-terminovany', 'prevod-sporiaci',
                                        'prevod-bezny', 'vklad-hotovost', 'poplatok', 'prijem')) NOT NULL,

  --medzi 2 uctami
  cisloProtiuctu INTEGER
);

DROP INDEX IF EXISTS zIndex CASCADE;
CREATE INDEX zIndex ON zakaznici(aktivny, datumAktivovania, EXTRACT(YEAR FROM datumAktivovania));

DROP INDEX IF EXISTS kIndex CASCADE;
CREATE INDEX kIndex ON kurzy(zMeny, naMenu);

DROP INDEX IF EXISTS uIndex CASCADE;
CREATE INDEX uIndex ON ucty(zakaznikId, typ);

DROP INDEX IF EXISTS tIndex CASCADE;
CREATE INDEX tIndex ON transakcie(ucetId, EXTRACT(MONTH FROM datum), EXTRACT(YEAR FROM datum), typ);