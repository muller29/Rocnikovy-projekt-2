/**
 *
 * @author Alexander Šimko
 * @author Konád Müller
 *
 * casti kodu, ktorych autorom je Alexander Šimko su oznacene
 */

--------------- Autor - Alexander Šimko - zac ---------------

-- Najprv zmazeme vsetky data. Mohli by sme to robit rucne cez DELETE po jednej tabulke.
-- Museli by sme ale brat do uvahy zavislosti medzi tabulkami. Takto to za nas spravi TRUNCATE.

truncate table zakaznici, ucty, meny, kurzy, platobneKarty, transakcie restart identity cascade;


---- pomocne tabulky na generovanie dat

-- first names

drop table if exists first_names cascade;
create table first_names
(
    first_name varchar
);

insert into first_names (first_name)
values	('James'), ('Willie'), ('Chad'), ('Zachary'), ('Mathew'),
	('John'), ('Ralph'), ('Jacob'), ('Corey'), ('Tyrone'),
	('Robert'), ('Lawrence'), ('Lee'), ('Herman'), ('Darren'),
	('Michael'), ('Nicholas'), ('Melvin'), ('Maurice'), ('Lonnie'),
	('William'), ('Roy'), ('Alfred'), ('Vernon'), ('Lance'),
	('David'), ('Benjamin'), ('Kyle'), ('Roberto'), ('Cody');

-- last names

drop table if exists last_names cascade;
create table last_names
(
    last_name varchar
);

insert into last_names (last_name)
values	('Smith'), ('Jones'), ('Taylor'), ('Williams'), ('Brown'),
	('Davies'), ('Evans'), ('Wilson'), ('Thomas'), ('Roberts'),
	('Johnson'), ('Lewis'), ('Walker'), ('Robinson'), ('Wood'),
	('Thompson'), ('White'), ('Watson'), ('Jackson'), ('Wright'),
	('Green'), ('Harris'), ('Cooper'), ('King'), ('Lee'),
	('Martin'), ('Clarke'), ('James'), ('Morgan'), ('Hughes'),
	('Edwards'), ('Hill'), ('Moore'), ('Clark'), ('Harrison'),
	('Scott'), ('Young'), ('Morris'), ('Hall'), ('Ward'),
	('Turner'), ('Carter'), ('Phillips'), ('Mitchell'), ('Patel'),
	('Adams'), ('Campbell'), ('Anderson'), ('Allen'), ('Cook');


---- hlavne tabulky

-- customers

create or replace function random_first_name() returns varchar language sql as
$$
select first_name from first_names tablesample system_rows(10) order by random() limit 1
$$;

create or replace function random_last_name() returns varchar language sql as
$$
select last_name from last_names tablesample system_rows(10) order by random() limit 1
$$;

----------------------- koniec -----------------------

CREATE OR replace function randomRodneCislo() RETURNS BIGINT AS $$
DECLARE
  rodne_cislo BIGINT;
  cyklus bool;
BEGIN
  cyklus = true;
  WHILE cyklus LOOP
    rodne_cislo := floor(random() * (9999999999 - 1000000000 + 1)) + 1000000000;
    cyklus := EXISTS(SELECT true FROM zakaznici z WHERE z.rodneCislo = rodne_cislo);
  END LOOP;
  RETURN rodne_cislo;
END;
$$ LANGUAGE PLPGSQL VOLATILE;

CREATE OR replace function randomSuma() RETURNS NUMERIC LANGUAGE SQL AS $$
SELECT (random() * (10000 - 1000) + 1000)::NUMERIC;
$$;

CREATE OR replace function randomMena() RETURNS INTEGER LANGUAGE SQL AS $$
SELECT id FROM meny
ORDER BY random() LIMIT 1
$$;

CREATE OR replace function randomBeznyUcet() RETURNS INTEGER LANGUAGE SQL AS $$
SELECT id FROM ucty
WHERE typ = 'bezny'
ORDER BY random() LIMIT 1
$$;

CREATE OR REPLACE FUNCTION randomAktivnyBeznyUcet() RETURNS INTEGER LANGUAGE SQL AS $$
SELECT id FROM ucty
WHERE typ = 'bezny' AND aktivny IS TRUE
ORDER BY random() LIMIT 1
$$;

CREATE OR REPLACE FUNCTION randomAktivnyBeznyASporiaciUcetOkrem(ucetId INTEGER) RETURNS INTEGER LANGUAGE SQL AS $$
SELECT id FROM ucty
WHERE typ in ('bezny', 'sporiaci') AND aktivny IS TRUE AND id != ucetId
ORDER BY random() LIMIT 1
$$;

CREATE OR REPLACE FUNCTION randomAktivnySporiaciUcet() RETURNS INTEGER LANGUAGE SQL AS $$
SELECT id FROM ucty
WHERE typ = 'sporiaci' AND aktivny IS TRUE
ORDER BY random() LIMIT 1
$$;

CREATE OR REPLACE FUNCTION randomAktivnyTerminovanyUcet(d DATE) RETURNS INTEGER LANGUAGE SQL AS $$
SELECT id FROM ucty
WHERE typ = 'terminovany' AND aktivny IS TRUE AND dobaviazanosti < d
ORDER BY random() LIMIT 1
$$;



INSERT INTO zakaznici (meno, priezvisko, rodnecislo, aktivny, datumevidencii, datumdeaktivovania, datumaktivovania)
SELECT 	random_first_name(),
        random_last_name(),
        randomRodneCislo(),
        CASE floor(random() * 3) WHEN 0 THEN FALSE WHEN 1 THEN TRUE WHEN 2 THEN TRUE END AS aktivny,
        date((CURRENT_DATE - '5 years'::INTERVAL) + trunc(random() * 1095) * '1 day'::INTERVAL) AS datumEvidencii,
        NULL AS datumdeaktivovania,
        NULL AS datumaktivovania
FROM generate_series(1, 10000) as seq(i);

UPDATE zakaznici
SET datumdeaktivovania = date((datumevidencii) + trunc((random() * (365-180))+180) * '1 day'::INTERVAL)
WHERE NOT aktivny;

UPDATE zakaznici
SET datumaktivovania = date((datumdeaktivovania) + trunc(random() * 120) * '1 day'::INTERVAL),
aktivny = TRUE
WHERE NOT aktivny AND random() < 0.4;

INSERT INTO meny(nazov)
VALUES ('EUR'), ('CZK'), ('AUD'), ('USD'), ('GBP'),
	('HUF'), ('DKK'), ('EGP'), ('TRY'), ('UAH'),
	('RON'), ('RUB'), ('CHF'), ('SEK'), ('JPY'), ('CNY');

INSERT INTO kurzy(kurz, zmeny, namenu)
SELECT random() * 31 AS kurz,
meny1.id AS zmeny,
meny2.id AS namenu FROM meny meny1 CROSS JOIN meny meny2 WHERE meny1.nazov != meny2.nazov;

--bezne ucty
INSERT INTO ucty(suma, sumatrans, aktivny, datumvytvorenia, zakaznikid, menaid, typ, urok,
                 dobaviazanosti, prepojenie)
  SELECT CASE WHEN z.aktivny IS TRUE THEN randomSuma() WHEN z.aktivny IS FALSE THEN 0 END AS suma,
    NULL AS sumaTrans,
    CASE WHEN z.aktivny IS TRUE THEN TRUE WHEN z.aktivny IS FALSE THEN FALSE END AS aktivny,
    z.datumevidencii + floor(random() * 170) * '1 day'::INTERVAL AS datumVytvorenia,
    z.id AS zakanikId,
    randomMena() AS menaId,
    'bezny' AS typ,
    NULL AS urok,
    NULL AS dobaViazanosti,
    NULL AS prepojenie
  FROM  zakaznici z
  WHERE random() < 0.7;

--sporiace ucty
INSERT INTO ucty(suma, sumatrans, aktivny, datumvytvorenia, zakaznikid, menaid, typ, urok,
                 dobaviazanosti, prepojenie)
  SELECT CASE WHEN z.aktivny IS TRUE THEN randomSuma() WHEN z.aktivny IS FALSE THEN 0 END AS suma,
         NULL AS sumaTrans,
         CASE WHEN z.aktivny IS TRUE THEN TRUE WHEN z.aktivny IS FALSE THEN FALSE END AS aktivny,
         u.datumvytvorenia + floor(random() * 10) * '1 day'::INTERVAL AS datumVytvorenia,
         z.id AS zakanikId,
         u.menaid AS menaId,
         'sporiaci' AS typ,
         random() * (5-1.5) + 1.5 AS urok,
         NULL AS dobaViazanosti,
         u.id AS prepojenie
  FROM ucty u JOIN zakaznici z
      ON u.zakaznikid = z.id
         AND u.typ = 'bezny'
  WHERE random() < 0.7;

--terminovane ucty
INSERT INTO ucty(suma, sumatrans, aktivny, datumvytvorenia, zakaznikid, menaid, typ, urok,
                 dobaviazanosti, prepojenie)
  SELECT CASE WHEN z.aktivny IS TRUE THEN randomSuma() WHEN z.aktivny IS FALSE THEN 0 END AS suma,
         NULL AS sumaTrans,
         CASE WHEN z.aktivny IS TRUE THEN TRUE WHEN z.aktivny IS FALSE THEN FALSE END AS aktivny,
         z.datumevidencii + floor(random() * 170) * '1 day'::INTERVAL AS datumVytvorenia,
         z.id AS zakanikId,
         randomMena() AS menaId,
         'terminovany' AS typ,
         random() * (10-5) + 5 AS urok,
         z.datumevidencii + floor((random() * (3650 - 730))+730) * '1 day'::INTERVAL AS dobaViazanosti,
         NULL AS prepojenie
  FROM  zakaznici z
  WHERE z.datumdeaktivovania IS NULL AND random() < 0.7;


UPDATE ucty SET sumaTrans = suma;

/*UPDATE ucty
SET urok = 0
WHERE typ = 'terminovany' AND dobaviazanosti < CURRENT_DATE;*/


INSERT INTO platobneKarty (kod, ucetid)
    SELECT floor(random() * (9999-1000)) + 1000 AS kod,
      randomBeznyUcet() AS ucetId
FROM generate_series(1, 2000) AS seq(i);


------TRANSAKCIE------

--vklad/vyber
INSERT INTO transakcie (ucetId, kartaId, suma, datum, typ, cisloprotiuctu)
    SELECT randomAktivnyBeznyUcet() as ucetId,
      NULL AS kartaId,
      floor(random() * (300-20) + 20) AS suma,
      date((CURRENT_DATE - '90 days'::INTERVAL) + trunc(random() * 90) * '1 day'::INTERVAL) AS datum,
      CASE floor(random() * 3) WHEN 0 THEN 'vklad-hotovost' WHEN 1 THEN 'vyber-hotovost'
      WHEN 2 THEN 'vyber-kartou' END AS typ,
      NULL AS cisloProtiuctu
FROM generate_series(1, 10000) as seq(i);

UPDATE transakcie t SET
  kartaId = (SELECT k.id FROM platobneKarty k WHERE k.ucetId = t.ucetId AND t.typ = 'vyber-kartou'
    ORDER BY random() LIMIT 1);

DELETE FROM transakcie t WHERE t.typ = 'vyber-kartou' and t.kartaId IS NULL;


--bezny -> bezny/sporiaci
INSERT INTO transakcie (ucetId, kartaId, suma, datum, typ, cisloprotiuctu)
  SELECT randomAktivnyBeznyUcet() AS ucetId,
         NULL AS kartaId,
         floor(random() * (300-20) + 20) AS suma,
         date((CURRENT_DATE - '90 days'::INTERVAL) + trunc(random() * 90) * '1 day'::INTERVAL) AS datum,
         'prevod-bezny' AS typ,
         NULL AS cisloProtiuctu
  FROM generate_series(1, 10000) as seq(i);

UPDATE  transakcie t set cisloProtiuctu = randomAktivnyBeznyASporiaciUcetOkrem(t.ucetId)
WHERE typ = 'prevod-bezny';


--sporiaci -> bezny
INSERT INTO transakcie (ucetId, kartaId, suma, datum, typ, cisloprotiuctu)
  SELECT randomAktivnySporiaciUcet() AS ucetId,
         NULL AS kartaId,
         floor(random() * (300-20) + 20) AS suma,
         date((CURRENT_DATE - '90 days'::INTERVAL) + trunc(random() * 90) * '1 day'::INTERVAL) AS datum,
         'prevod-sporiaci' AS typ,
         NULL AS cisloProtiuctu
  FROM generate_series(1, 10000) as seq(i);

UPDATE transakcie t SET cisloprotiuctu = (SELECT u.prepojenie FROM ucty u WHERE t.ucetid = u.id)
WHERE t.typ = 'prevod-sporiaci';


--terminovany -> bezny/sporiaci
INSERT INTO transakcie (ucetId, kartaId, suma, datum, typ, cisloprotiuctu)
  SELECT NULL AS ucetId,
         NULL AS kartaId,
         floor(random() * (300-20) + 20) AS suma,
         date((CURRENT_DATE - '90 days'::INTERVAL) + trunc(random() * 90) * '1 day'::INTERVAL) AS datum,
         'prevod-terminovany' AS typ,
         NULL AS cisloProtiuctu
  FROM generate_series(1, 5000) as seq(i);

UPDATE  transakcie t set ucetid = randomAktivnyTerminovanyUcet(t.datum)
WHERE typ = 'prevod-terminovany';

DELETE FROM transakcie t WHERE typ = 'prevod-terminovany' and ucetId is NULL;

UPDATE  transakcie t set cisloProtiuctu = randomAktivnyBeznyASporiaciUcetOkrem(t.ucetId)
WHERE typ = 'prevod-terminovany';


---- nakoniec zmazeme pomocne veci

drop table first_names, last_names cascade;


drop function random_first_name();
drop function random_last_name();
DROP function randomRodneCislo();
DROP function randomSuma();
DROP function randomMena();
DROP function randomBeznyUcet();
DROP function randomAktivnyBeznyUcet();
DROP function randomAktivnyBeznyASporiaciUcetOkrem(ucetId INTEGER);
DROP function randomAktivnySporiaciUcet();
DROP function randomAktivnyTerminovanyUcet(d Date);